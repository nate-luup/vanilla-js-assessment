export default (props) => {
  return <div style={{ padding: 20 }}>{props.children}</div>;
};
