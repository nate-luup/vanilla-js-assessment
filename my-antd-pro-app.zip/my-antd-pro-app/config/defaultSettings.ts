import { Settings as LayoutSettings } from '@ant-design/pro-layout';

const Settings: LayoutSettings & {
  pwa?: boolean;
  logo?: string;
} = {
  navTheme: 'light',
  primaryColor: '#FA541C',
  layout: 'mix',
  // splitMenus: true,
  contentWidth: 'Fluid',
  fixedHeader: false,
  fixSiderbar: true,
  pwa: false,
  title: 'Tesla',
  logo: 'https://www.tesla.cn/themes/custom/tesla_frontend/assets/favicons/favicon.ico',
  iconfontUrl: '',
};

export default Settings;
