export default [
  {
    path: '/user',
    layout: false,
    routes: [
      { path: '/user', routes: [{ name: '登录', path: '/user/login', component: './user/Login' }] },
      { component: './404' },
    ],
  },
  { path: '/welcome', name: '欢迎', icon: 'smile', component: './Welcome' },
  {
    path: '/admin',
    name: '管理页',
    icon: 'crown',
    access: 'canAdmin',
    component: './Admin',
    routes: [
      { path: '/admin/sub-page', name: '二级管理页', icon: 'smile', component: './Welcome' },
      { component: './404' },
    ],
  },
  { name: '查询表格', icon: 'table', path: '/list', component: './TableList' },
  { path: '/', redirect: '/welcome' },
  {
    name: '新页面',
    path: '/new',
    component: '../layouts/index',
    icon: 'smile',
    routes: [{ path: '/new/page', icon: 'smile', name: '二级管理页', component: './NewPage' }],
  },
  {
    name: '学习pro components',
    path: '/procomponents',
    component: '../layouts/index',
    icon: 'smile',
    routes: [
      {
        path: '/procomponents/form',
        name: '表单页',
        icon: 'smile',
        component: './procomponents/form',
      },
      {
        path: '/procomponents/layout',
        name: 'layout页',
        icon: 'smile',
        component: './procomponents/prolayout',
      },
      {
        path: '/procomponents/container',
        name: 'PageContainer页',
        icon: 'smile',
        component: './procomponents/PageContainer',
      },
    ],
  },
  { component: './404' },
];
